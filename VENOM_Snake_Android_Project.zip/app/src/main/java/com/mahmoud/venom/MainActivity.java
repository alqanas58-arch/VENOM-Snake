package com.mahmoud.venom;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.Window;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(8,6,18));
        getWindow().setNavigationBarColor(Color.rgb(8,6,18));
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.rgb(8,6,18));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }
}