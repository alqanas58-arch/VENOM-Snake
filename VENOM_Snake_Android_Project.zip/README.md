# VENOM Snake — Android project

This is a native Android WebView project containing the VENOM Snake game.

Features:
- Wrap-around walls
- Swipe controls + on-screen controls
- Score and persistent best score
- Increasing speed
- Neon visual identity
- Portrait mobile layout

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android device or choose Build > Build APK(s).

Package: com.mahmoud.venom
Version: 1.0
